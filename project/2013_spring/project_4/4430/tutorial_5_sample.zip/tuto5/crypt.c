/* crypt.c -- demonstrate the use of crypt() in generating filenames
 *
 * Usage: ./crypt [url]
 * e.g.,
 * ./crypt "http://www.cse.cuhk.edu.hk/csci4430/index.html"
 */

#define _XOPEN_SOURCE 700  /* Needed for crypt().
                            * Remember to define this before the include's. */
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>        /* Needed for crypt(). */

int main(int argc, char **argv) {
  if (argc != 2) {
    printf("Usage: %s [url]\n", argv[0]);
    exit(1);
  }

  /* crypt() stores its return value in a static variable which might be
   * overwritten later. Better copy the result to another variable as shown in
   * the specification.
   *
   * Also, crypt() is NOT thread-safe. You should invoke it
   * within the critical section of your code or you should use crypt_r()
   * instead. See "man 3 crypt" for more info. */
  char *result = crypt(argv[1], "$1$00$");

  printf("Entire result from crypt(): %s\n", result);  /* strlen(result) = 28 */

  result += 6;  /* The first 6 bytes are useless, strlen(result) = 22 */
  for (int i=0; i<22; i++) {
    if (result[i] == '/') { result[i] = '_'; }
  }
  printf("You should create your cache file in: cache/%s\n", result);
  return 0;
}
