/* stat.c -- demonstrate how to obtain info about a locally cached file using
 * stat() and also how to use several time conversion functions
 *
 * Usage: ./stat [file]
 * e.g.,
 * ./stat stat.c
 * ./stat some-non-existent-file
 *
 * This program outputs something only when file exists.
 * You can try "touch stat.c" to update its last modification time.
 */

#define _XOPEN_SOURCE 700  /* Needed for strptime().
                            * Remember to define this before the include's. */
#define _BSD_SOURCE     /* Needed for timegm() */
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>  /* Needed for stat() */
#include <sys/stat.h>   /* Needed for stat() */
#include <time.h>       /* Needed for gmtime_r(), timegm(), str*time() */
#include <unistd.h>     /* Needed for stat() */

/* error-handling macro, see pthread.c from tutorial_4 for details */
#define show_error(call) do { perror(call); exit(1); } while (0)

int get_file_info(const char *const path, struct stat *sb) {
  int ret =  stat(path, sb);
  if (ret) {
    if (errno == ENOENT) {
      /* file does not exist, create one */
    } else {
      show_error("stat");
    }
  }
  return ret;
}

int main(int argc, char **argv) {
  if (argc != 2) {
    printf("Usage: %s [file]\n", argv[0]);
    exit(1);
  }

  /* struct to pass to stat() which will hold info about the queried file */
  struct stat sb;

  if (get_file_info(argv[1], &sb)) {
    /* file is newly created, what should we do? */
  } else {
    printf("Last modification time of stat.c: %ld\n", sb.st_mtime);

    /* convert local integer time to HTTP date string (GMT) */
    struct tm tm;
    gmtime_r(&sb.st_mtime, &tm);
    char last_modified_time[50] = {0};
    size_t len = strftime(last_modified_time, sizeof(last_modified_time),
                          "%a, %d %b %Y %H:%M:%S GMT", &tm);
    printf("Or, in HTTP date format (len=%u): %s\n", len, last_modified_time);

    /* convert string (GMT) back to local integer time */
    strptime(last_modified_time, "%a, %d %b %Y %H:%M:%S GMT", &tm);
    printf("Back to integer time: %ld\n", timegm(&tm));
  }

  return 0;
}
