#!/bin/sh

echo "Executing Naive_MODE0_DAY3..."
./Naive 0 3 >> Naive_MODE0_DAY3.txt
echo "Finished Executing Naive_MODE0_DAY3."

echo "Executing Naive_MODE1_DAY3..."
./Naive 1 3 >> Naive_MODE1_DAY3.txt
echo "Finished Executing Naive_MODE1_DAY3."

echo "Executing Naive_MODE2_DAY3..."
./Naive 2 3 >> Naive_MODE2_DAY3.txt
echo "Finished Executing Naive_MODE2_DAY3."

echo "Executing ApplicationLevel_PERDICTINTERVAL3_DAY3..."
./ApplicationLevel 3 3 >> ApplicationLevel_PERDICTINTERVAL3_DAY3.txt
echo "Finished ApplicationLevel_PERDICTINTERVAL3_DAY3."

echo "Executing ApplicationLevel_PERDICTINTERVAL6_DAY3..."
./ApplicationLevel 6 3 >> ApplicationLevel_PERDICTINTERVAL6_DAY3.txt
echo "Finished ApplicationLevel_PERDICTINTERVAL6_DAY3."