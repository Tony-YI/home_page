#include <gecode/int.hh>
#include <gecode/driver.hh>
#include <gecode/int/branch.hh>
#include <gecode/minimodel.hh>
#include <gecode/search.hh>
#include <ctime>
#include <random> //for normal distribution

using namespace Gecode;
using namespace std;

//#define NUM_TOTAL_INTERVALS 	60	// number of total intervals per 10 minutes interval, each interval is 10s
#define NUM_TOTAL_INTERVALS 	60

#define POWER_INTERVAL_TEMP NUM_TOTAL_INTERVALS * 5		// power consumption of temperature sensor for 1 sample, require 10s to take a sample
#define POWER_INTERVAL_RH 	NUM_TOTAL_INTERVALS * 5		// power consumption of relative humidity sensor for 1 sample, require 10s to take a sample
#define POWER_INTERVAL_CO 	NUM_TOTAL_INTERVALS * 10	// power consumption of CO sensor for 1 sample, require 10s to take a sample
#define POWER_INTERVAL_SO2 	NUM_TOTAL_INTERVALS * 10	// power consumption of SO2 sensor for 1 sample, require 10s to take a sample
#define POWER_INTERVAL_O3 	NUM_TOTAL_INTERVALS * 10	// power consumption of O3 sensor for 1 sample, require 10s to take a sample
#define POWER_INTERVAL_NO2 	NUM_TOTAL_INTERVALS * 10	// power consumption of NO2 sensor for 1 sample, require 10s to take a sample
#define POWER_INTERVAL_PM 	NUM_TOTAL_INTERVALS * 30	// power consumption of particulate matter sensor for 1 sample, require 10s to take a sample
#define POWER_INTERVAL_RL 	NUM_TOTAL_INTERVALS * 120	// power consumption of radio link for 1 transmission, require 10s to tramsimit

#define DATA_GENERATE_TEMP 	16	// data generated (in bytes) by temperature sensor for 1 sample
#define DATA_GENERATE_RH 	16	// data generated (in bytes) by relative humidity sensor for 1 sample
#define DATA_GENERATE_CO 	16	// data generated (in bytes) by CO sensor for 1 sample
#define DATA_GENERATE_SO2 	16	// data generated (in bytes) by SO2 sensor for 1 sample
#define DATA_GENERATE_O3 	16	// data generated (in bytes) by O3 sensor for 1 sample
#define DATA_GENERATE_NO2 	16	// data generated (in bytes) by NO2 sensor for 1 sample
#define DATA_GENERATE_PM 	16	// data generated (in bytes) by particulate matter sensor for 1 sample
#define DATA_CONSUME_RL 	250	// data consumed (in bytes) by radio link for 1 transmission

//6 6 6 6 5 1 1 2 428 560 640 0 348
int ESTIMATE_INTERVAL_POWER;
int RATE_CO = 6;
int RATE_SO2 = 6;
int RATE_O3 = 6;
int RATE_NO2 = 6;
int RATE_PM = 5;
int RATE_TEMP = 1;
int RATE_RH = 1;
int RATE_RL = 2;
int ENERGY_IN_BATTERY = 428;
// int TOTAL_HARVESTED_ENERGY = 560;
int TOTAL_HARVESTED_ENERGY = 640;
int TOTAL_CONSUMED_ENERGY = 640;
int AVERAGE_INTERVAL_POWER_HARVEST_DEVICE = TOTAL_HARVESTED_ENERGY * NUM_TOTAL_INTERVALS / NUM_TOTAL_INTERVALS;
int AVERAGE_INTERVAL_POWER_COMSUMED = TOTAL_CONSUMED_ENERGY * NUM_TOTAL_INTERVALS / NUM_TOTAL_INTERVALS;

int evenly_CO_abs = NUM_TOTAL_INTERVALS * 100 / RATE_CO; //100 is used to elimite .digits
int evenly_SO2_abs = NUM_TOTAL_INTERVALS * 100 / RATE_SO2; //100 is used to elimite .digits
int evenly_O3_abs = NUM_TOTAL_INTERVALS * 100 / RATE_O3; //100 is used to elimite .digits
int evenly_NO2_abs = NUM_TOTAL_INTERVALS * 100 / RATE_NO2; //100 is used to elimite .digits
int evenly_PM_abs = NUM_TOTAL_INTERVALS * 100 / RATE_PM; //100 is used to elimite .digits
int evenly_TEMP_abs = NUM_TOTAL_INTERVALS * 100 / RATE_TEMP; //100 is used to elimite .digits
int evenly_RH_abs = NUM_TOTAL_INTERVALS * 100 / RATE_RH; //100 is used to elimite .digits
int evenly_RL_abs = NUM_TOTAL_INTERVALS * 100 / RATE_RL; //100 is used to elimite .digits

int ESTIMATE_POWER_PER_INTERVAL[NUM_TOTAL_INTERVALS];
void init_estimate_interval_power()
{
	default_random_engine generator;
	normal_distribution<double> distribution(0, AVERAGE_INTERVAL_POWER_HARVEST_DEVICE * 10 / 100.0);

	int target = AVERAGE_INTERVAL_POWER_HARVEST_DEVICE * NUM_TOTAL_INTERVALS;

	for(int i = 0; i < NUM_TOTAL_INTERVALS; i++)
	{
		int noise = distribution(generator);
		ESTIMATE_POWER_PER_INTERVAL[i] = AVERAGE_INTERVAL_POWER_HARVEST_DEVICE + noise;
		target -= ESTIMATE_POWER_PER_INTERVAL[i];
	}

	int adder = 0;
	if(target >= 0)
	{
		adder = 1;
	}
	else
	{
		adder = -1;
	}
	for(int i = 0; i < abs(target); i++)
	{
		ESTIMATE_POWER_PER_INTERVAL[i % NUM_TOTAL_INTERVALS] += adder;
	}

	target = AVERAGE_INTERVAL_POWER_HARVEST_DEVICE * NUM_TOTAL_INTERVALS;

	for(int i = 0; i < NUM_TOTAL_INTERVALS; i++)
	{
		target -= ESTIMATE_POWER_PER_INTERVAL[i];
	}

	if(target != 0)
	{
		cout << "ERROR in init_estimate_interval_power()" << endl;
		exit(-1);
	}
}

void print_estimate_interval_power()
{
	cout << "ESTIMATE_INTERVAL_POWER:\t";
	for(int i = 0; i < NUM_TOTAL_INTERVALS; i++)
	{
		cout << ESTIMATE_POWER_PER_INTERVAL[i] << " ";
	}
	cout << endl;
}

class RealtimeScheduling: public Space
{
protected:
	IntVarArray index_CO; //when the CO sensor take a sample, 0 means not taking sample at that interval
	IntVarArray index_SO2; //when the SO2 sensor take a sample, 0 means not taking sample at that interval
	IntVarArray index_O3; //when the O3 sensor take a sample, 0 means not taking sample at that interval
	IntVarArray index_NO2; //when the NO2 sensor take a sample, 0 means not taking sample at that interval
	IntVarArray index_PM; //when the PM sensor take a sample, 0 means not taking sample at that interval
	IntVarArray index_TEMP; //when the TEMP sensor take a sample, 0 means not taking sample at that interval
	IntVarArray index_RH; //when the RH sensor take a sample, 0 means not taking sample at that interval
	IntVarArray index_RL; //when the RL sensor take a sample, 0 means not taking sample at that interval

	IntVarArray power_require_per_interval; //the power required for each interval
	IntVarArray power_remian_last_interval; //the power remained of the last interval

	IntVarArray index_index_CO; //when the CO snesor take a sample at index i, the value at index_index_CO[i] = i * index_CO[i] + index_index_CO[i - 1] - index_index_CO[i - 1] * index_CO[i]
	IntVarArray index_index_SO2; //when the SO2 snesor take a sample at index i, the value at index_index_SO2[i] = i * index_SO2[i] + index_index_SO2[i - 1] - index_index_SO2[i - 1] * index_SO2[i]
	IntVarArray index_index_O3; //when the O3 snesor take a sample at index i, the value at index_index_O3[i] = i * index_O3[i] + index_index_O3[i - 1] - index_index_O3[i - 1] * index_O3[i]
	IntVarArray index_index_NO2; //when the NO2 snesor take a sample at index i, the value at index_index_NO2[i] = i * index_NO2[i] + index_index_NO2[i - 1] - index_index_NO2[i - 1] * index_NO2[i]
	IntVarArray index_index_PM; //when the PM snesor take a sample at index i, the value at index_index_PM[i] = i * index_PM[i] + index_index_PM[i - 1] - index_index_PM[i - 1] * index_PM[i]
	IntVarArray index_index_TEMP; //when the TEMP snesor take a sample at index i, the value at index_index_TEMP[i] = i * index_TEMP[i] + index_index_TEMP[i - 1] - index_index_TEMP[i - 1] * index_TEMP[i]
	IntVarArray index_index_RH; //when the RH snesor take a sample at index i, the value at index_index_RH[i] = i * index_RH[i] + index_index_RH[i - 1] - index_index_RH[i - 1] * index_RH[i]
	IntVarArray index_index_RL; //when the RL snesor take a sample at index i, the value at index_index_RL[i] = i * index_RL[i] + index_index_RL[i - 1] - index_index_RL[i - 1] * index_RL[i]

	IntVar evenly_CO; //describe how evenly CO sensing interverls are distributed
	IntVar evenly_SO2; //describe how evenly SO2 sensing interverls are distributed
	IntVar evenly_O3; //describe how evenly O3 sensing interverls are distributed
	IntVar evenly_NO2; //describe how evenly NO2 sensing interverls are distributed
	IntVar evenly_PM; //describe how evenly PM sensing interverls are distributed
	IntVar evenly_TEMP; //describe how evenly TEMP sensing interverls are distributed
	IntVar evenly_RH; //describe how evenly RH sensing interverls are distributed
	IntVar evenly_RL; //describe how evenly RL sensing interverls are distributed

	IntVarArray diff_CO_abs; //difference between the solution 'evenly' and perfect 'evenly'
	IntVarArray diff_SO2_abs; //difference between the solution 'evenly' and perfect 'evenly'
	IntVarArray diff_O3_abs; //difference between the solution 'evenly' and perfect 'evenly'
	IntVarArray diff_NO2_abs; //difference between the solution 'evenly' and perfect 'evenly'
	IntVarArray diff_PM_abs; //difference between the solution 'evenly' and perfect 'evenly'
	IntVarArray diff_TEMP_abs; //difference between the solution 'evenly' and perfect 'evenly'
	IntVarArray diff_RH_abs; //difference between the solution 'evenly' and perfect 'evenly'
	IntVarArray diff_RL_abs; //difference between the solution 'evenly' and perfect 'evenly'

	BoolVarArray cof_CO;
	BoolVarArray cof_SO2;
	BoolVarArray cof_O3;
	BoolVarArray cof_NO2;
	BoolVarArray cof_PM;
	BoolVarArray cof_TEMP;
	BoolVarArray cof_RH;
	BoolVarArray cof_RL;

public:
	RealtimeScheduling(void)
	:index_CO(*this, NUM_TOTAL_INTERVALS, 0, 1), index_SO2(*this, NUM_TOTAL_INTERVALS, 0, 1),
	 index_O3(*this, NUM_TOTAL_INTERVALS, 0, 1), index_NO2(*this, NUM_TOTAL_INTERVALS, 0, 1),
	 index_PM(*this, NUM_TOTAL_INTERVALS, 0, 1), index_TEMP(*this, NUM_TOTAL_INTERVALS, 0, 1),
	 index_RH(*this, NUM_TOTAL_INTERVALS, 0, 1), index_RL(*this, NUM_TOTAL_INTERVALS, 0, 1),
	 power_require_per_interval(*this, NUM_TOTAL_INTERVALS, 0 , AVERAGE_INTERVAL_POWER_COMSUMED * NUM_TOTAL_INTERVALS),
	 power_remian_last_interval(*this, NUM_TOTAL_INTERVALS, 0 , AVERAGE_INTERVAL_POWER_COMSUMED * NUM_TOTAL_INTERVALS),
	 index_index_CO(*this, NUM_TOTAL_INTERVALS, 0, NUM_TOTAL_INTERVALS), index_index_SO2(*this, NUM_TOTAL_INTERVALS, 0, NUM_TOTAL_INTERVALS),
	 index_index_O3(*this, NUM_TOTAL_INTERVALS, 0, NUM_TOTAL_INTERVALS), index_index_NO2(*this, NUM_TOTAL_INTERVALS, 0, NUM_TOTAL_INTERVALS),
	 index_index_PM(*this, NUM_TOTAL_INTERVALS, 0, NUM_TOTAL_INTERVALS), index_index_TEMP(*this, NUM_TOTAL_INTERVALS, 0, NUM_TOTAL_INTERVALS),
	 index_index_RH(*this, NUM_TOTAL_INTERVALS, 0, NUM_TOTAL_INTERVALS), index_index_RL(*this, NUM_TOTAL_INTERVALS, 0, NUM_TOTAL_INTERVALS),
	 evenly_CO(*this, 0, NUM_TOTAL_INTERVALS * 100), diff_CO_abs(*this, NUM_TOTAL_INTERVALS - 1, 0, NUM_TOTAL_INTERVALS * 100), cof_CO(*this, NUM_TOTAL_INTERVALS - 1),
	 evenly_SO2(*this, 0, NUM_TOTAL_INTERVALS * 100), diff_SO2_abs(*this, NUM_TOTAL_INTERVALS - 1, 0, NUM_TOTAL_INTERVALS * 100), cof_SO2(*this, NUM_TOTAL_INTERVALS - 1),
	 evenly_O3(*this, 0, NUM_TOTAL_INTERVALS * 100), diff_O3_abs(*this, NUM_TOTAL_INTERVALS - 1, 0, NUM_TOTAL_INTERVALS * 100), cof_O3(*this, NUM_TOTAL_INTERVALS - 1),
	 evenly_NO2(*this, 0, NUM_TOTAL_INTERVALS * 100), diff_NO2_abs(*this, NUM_TOTAL_INTERVALS - 1, 0, NUM_TOTAL_INTERVALS * 100), cof_NO2(*this, NUM_TOTAL_INTERVALS - 1),
	 evenly_PM(*this, 0, NUM_TOTAL_INTERVALS * 100), diff_PM_abs(*this, NUM_TOTAL_INTERVALS - 1, 0, NUM_TOTAL_INTERVALS * 100), cof_PM(*this, NUM_TOTAL_INTERVALS - 1),
	 evenly_TEMP(*this, 0, NUM_TOTAL_INTERVALS * 100), diff_TEMP_abs(*this, NUM_TOTAL_INTERVALS - 1, 0, NUM_TOTAL_INTERVALS * 100), cof_TEMP(*this, NUM_TOTAL_INTERVALS - 1),
	 evenly_RH(*this, 0, NUM_TOTAL_INTERVALS * 100), diff_RH_abs(*this, NUM_TOTAL_INTERVALS - 1, 0, NUM_TOTAL_INTERVALS * 100), cof_RH(*this, NUM_TOTAL_INTERVALS - 1),
	 evenly_RL(*this, 0, NUM_TOTAL_INTERVALS * 100), diff_RL_abs(*this, NUM_TOTAL_INTERVALS - 1, 0, NUM_TOTAL_INTERVALS * 100), cof_RL(*this, NUM_TOTAL_INTERVALS - 1)
	{
		//count the number of sample times inside the 60 intervals
		count(*this, index_CO, 1, IRT_EQ, RATE_CO);
		count(*this, index_SO2, 1, IRT_EQ, RATE_SO2);
		count(*this, index_O3, 1, IRT_EQ, RATE_O3);
		count(*this, index_NO2, 1, IRT_EQ, RATE_NO2);
		count(*this, index_PM, 1, IRT_EQ, RATE_PM);
		count(*this, index_TEMP, 1, IRT_EQ, RATE_TEMP);
		count(*this, index_RH, 1, IRT_EQ, RATE_RH);
		count(*this, index_RL, 1, IRT_EQ, RATE_RL);

		//calculating the index_index_Sensor[i]
		//for distributing the 1s evenly
		for(int i = 0; i < NUM_TOTAL_INTERVALS; i++)
		{
			if(i == 0)
			{
				rel(*this, index_index_CO[i] == expr(*this, (i + 1) * index_CO[i]));
				rel(*this, index_index_SO2[i] == expr(*this, (i + 1) * index_SO2[i]));
				rel(*this, index_index_O3[i] == expr(*this, (i + 1) * index_O3[i]));
				rel(*this, index_index_NO2[i] == expr(*this, (i + 1) * index_NO2[i]));
				rel(*this, index_index_PM[i] == expr(*this, (i + 1) * index_PM[i]));
				rel(*this, index_index_TEMP[i] == expr(*this, (i + 1) * index_TEMP[i]));
				rel(*this, index_index_RH[i] == expr(*this, (i + 1) * index_RH[i]));
				rel(*this, index_index_RL[i] == expr(*this, (i + 1) * index_RL[i]));
			}
			else
			{
				rel(*this, index_index_CO[i] == expr(*this, (i + 1) * index_CO[i] + index_index_CO[i - 1] - index_index_CO[i - 1] * index_CO[i]));
				rel(*this, index_index_SO2[i] == expr(*this, (i + 1) * index_SO2[i] + index_index_SO2[i - 1] - index_index_SO2[i - 1] * index_SO2[i]));
				rel(*this, index_index_O3[i] == expr(*this, (i + 1) * index_O3[i] + index_index_O3[i - 1] - index_index_O3[i - 1] * index_O3[i]));
				rel(*this, index_index_NO2[i] == expr(*this, (i + 1) * index_NO2[i] + index_index_NO2[i - 1] - index_index_NO2[i - 1] * index_NO2[i]));
				rel(*this, index_index_PM[i] == expr(*this, (i + 1) * index_PM[i] + index_index_PM[i - 1] - index_index_PM[i - 1] * index_PM[i]));
				rel(*this, index_index_TEMP[i] == expr(*this, (i + 1) * index_TEMP[i] + index_index_TEMP[i - 1] - index_index_TEMP[i - 1] * index_TEMP[i]));
				rel(*this, index_index_RH[i] == expr(*this, (i + 1) * index_RH[i] + index_index_RH[i - 1] - index_index_RH[i - 1] * index_RH[i]));
				rel(*this, index_index_RL[i] == expr(*this, (i + 1) * index_RL[i] + index_index_RL[i - 1] - index_index_RL[i - 1] * index_RL[i]));
			}	
		}

		for(int i = 0; i < NUM_TOTAL_INTERVALS - 1; i++)
		{
			cof_CO[i] = expr(*this, index_index_CO[i + 1] - index_index_CO[i] != 0 && index_index_CO[i] != 0);
			cof_SO2[i] = expr(*this, index_index_SO2[i + 1] - index_index_SO2[i] != 0 && index_index_SO2[i] != 0);
			cof_O3[i] = expr(*this, index_index_O3[i + 1] - index_index_O3[i] != 0 && index_index_O3[i] != 0);
			cof_NO2[i] = expr(*this, index_index_NO2[i + 1] - index_index_NO2[i] != 0 && index_index_NO2[i] != 0);
			cof_PM[i] = expr(*this, index_index_PM[i + 1] - index_index_PM[i] != 0 && index_index_PM[i] != 0);
			cof_TEMP[i] = expr(*this, index_index_TEMP[i + 1] - index_index_TEMP[i] != 0 && index_index_TEMP[i] != 0);
			cof_RH[i] = expr(*this, index_index_RH[i + 1] - index_index_RH[i] != 0 && index_index_RH[i] != 0);
			cof_RL[i] = expr(*this, index_index_RL[i + 1] - index_index_RL[i] != 0 && index_index_RL[i] != 0);

			IntVar temp_CO = expr(*this, (evenly_CO_abs - (index_index_CO[i + 1] - index_index_CO[i]) * 100) * cof_CO[i]);
			IntVar temp_SO2 = expr(*this, (evenly_SO2_abs - (index_index_SO2[i + 1] - index_index_SO2[i]) * 100) * cof_SO2[i]);
			IntVar temp_O3 = expr(*this, (evenly_O3_abs - (index_index_O3[i + 1] - index_index_O3[i]) * 100) * cof_O3[i]);
			IntVar temp_NO2 = expr(*this, (evenly_NO2_abs - (index_index_NO2[i + 1] - index_index_NO2[i]) * 100) * cof_NO2[i]);
			IntVar temp_PM = expr(*this, (evenly_PM_abs - (index_index_PM[i + 1] - index_index_PM[i]) * 100) * cof_PM[i]);
			IntVar temp_TEMP = expr(*this, (evenly_TEMP_abs - (index_index_TEMP[i + 1] - index_index_TEMP[i]) * 100) * cof_TEMP[i]);
			IntVar temp_RH = expr(*this, (evenly_RH_abs - (index_index_RH[i + 1] - index_index_RH[i]) * 100) * cof_RH[i]);
			IntVar temp_RL = expr(*this, (evenly_RL_abs - (index_index_RL[i + 1] - index_index_RL[i]) * 100) * cof_RL[i]);

			abs(*this, temp_CO, diff_CO_abs[i]);
			abs(*this, temp_SO2, diff_SO2_abs[i]);
			abs(*this, temp_O3, diff_O3_abs[i]);
			abs(*this, temp_NO2, diff_NO2_abs[i]);
			abs(*this, temp_PM, diff_PM_abs[i]);
			abs(*this, temp_TEMP, diff_TEMP_abs[i]);
			abs(*this, temp_RH, diff_RH_abs[i]);
			abs(*this, temp_RL, diff_RL_abs[i]);
		}

		rel(*this, evenly_CO == sum(diff_CO_abs));
		rel(*this, evenly_SO2 == sum(diff_SO2_abs));
		rel(*this, evenly_O3 == sum(diff_O3_abs));
		rel(*this, evenly_NO2 == sum(diff_NO2_abs));
		rel(*this, evenly_PM == sum(diff_PM_abs));
		rel(*this, evenly_TEMP == sum(diff_TEMP_abs));
		rel(*this, evenly_RH == sum(diff_RH_abs));
		rel(*this, evenly_RL == sum(diff_RL_abs));

		//IntVarArray power_require_per_interval(*this, NUM_TOTAL_INTERVALS, 0, 0);
		for(int i = 0; i < NUM_TOTAL_INTERVALS; i++)
		{
			rel(*this, power_require_per_interval[i] == expr(*this,
					index_CO[i] * POWER_INTERVAL_CO + index_SO2[i] * POWER_INTERVAL_SO2 +
					index_O3[i] * POWER_INTERVAL_O3 + index_NO2[i] * POWER_INTERVAL_NO2 +
					index_PM[i] * POWER_INTERVAL_PM + index_TEMP[i] * POWER_INTERVAL_TEMP +
					index_RH[i] * POWER_INTERVAL_RH + index_RL[i] * POWER_INTERVAL_RL));
		}

		//staisfy the power constraint for every interval
		// IntVarArray power_remian_last_interval(*this, NUM_TOTAL_INTERVALS, 0, AVERAGE_INTERVAL_POWER_HARVEST_DEVICE * NUM_TOTAL_INTERVALS);
		rel(*this, power_remian_last_interval[0] == 0);
		for(int i = 0; i < NUM_TOTAL_INTERVALS; i++)
		{
			rel(*this, power_require_per_interval[i] <= ESTIMATE_POWER_PER_INTERVAL[i] + power_remian_last_interval[i]);

			if(i < NUM_TOTAL_INTERVALS - 1)
			{
				rel(*this, power_remian_last_interval[i + 1] == expr(*this, ESTIMATE_POWER_PER_INTERVAL[i] + power_remian_last_interval[i] - power_require_per_interval[i]));
			}
		}

		branch(*this, this->index_CO, INT_VAR_SIZE_MAX(), INT_VAL_MAX());
		branch(*this, this->index_SO2, INT_VAR_SIZE_MAX(), INT_VAL_MAX());
		branch(*this, this->index_O3, INT_VAR_SIZE_MAX(), INT_VAL_MAX());
		branch(*this, this->index_NO2, INT_VAR_SIZE_MAX(), INT_VAL_MAX());
		branch(*this, this->index_PM, INT_VAR_SIZE_MAX(), INT_VAL_MAX());
		branch(*this, this->index_TEMP, INT_VAR_SIZE_MAX(), INT_VAL_MAX());
		branch(*this, this->index_RH, INT_VAR_SIZE_MAX(), INT_VAL_MAX());
		branch(*this, this->index_RL, INT_VAR_SIZE_MAX(), INT_VAL_MAX());

		branch(*this, this->power_require_per_interval, INT_VAR_SIZE_MIN(), INT_VAL_MIN());
		branch(*this, this->power_remian_last_interval, INT_VAR_SIZE_MIN(), INT_VAL_MIN());

		branch(*this, this->index_index_CO, INT_VAR_SIZE_MIN(), INT_VAL_MIN());
		branch(*this, this->index_index_SO2, INT_VAR_SIZE_MIN(), INT_VAL_MIN());
		branch(*this, this->index_index_O3, INT_VAR_SIZE_MIN(), INT_VAL_MIN());
		branch(*this, this->index_index_NO2, INT_VAR_SIZE_MIN(), INT_VAL_MIN());
		branch(*this, this->index_index_PM, INT_VAR_SIZE_MIN(), INT_VAL_MIN());
		branch(*this, this->index_index_TEMP, INT_VAR_SIZE_MIN(), INT_VAL_MIN());
		branch(*this, this->index_index_RH, INT_VAR_SIZE_MIN(), INT_VAL_MIN());
		branch(*this, this->index_index_RL, INT_VAR_SIZE_MIN(), INT_VAL_MIN());

		branch(*this, this->evenly_CO, INT_VAL_MIN());
		branch(*this, this->evenly_SO2, INT_VAL_MIN());
		branch(*this, this->evenly_O3, INT_VAL_MIN());
		branch(*this, this->evenly_NO2, INT_VAL_MIN());
		branch(*this, this->evenly_PM, INT_VAL_MIN());
		branch(*this, this->evenly_TEMP, INT_VAL_MIN());
		branch(*this, this->evenly_RH, INT_VAL_MIN());
		branch(*this, this->evenly_RL, INT_VAL_MIN());

		branch(*this, this->diff_CO_abs, INT_VAR_SIZE_MIN(), INT_VAL_MIN());
		branch(*this, this->diff_SO2_abs, INT_VAR_SIZE_MIN(), INT_VAL_MIN());
		branch(*this, this->diff_O3_abs, INT_VAR_SIZE_MIN(), INT_VAL_MIN());
		branch(*this, this->diff_NO2_abs, INT_VAR_SIZE_MIN(), INT_VAL_MIN());
		branch(*this, this->diff_PM_abs, INT_VAR_SIZE_MIN(), INT_VAL_MIN());
		branch(*this, this->diff_TEMP_abs, INT_VAR_SIZE_MIN(), INT_VAL_MIN());
		branch(*this, this->diff_RH_abs, INT_VAR_SIZE_MIN(), INT_VAL_MIN());
		branch(*this, this->diff_RL_abs, INT_VAR_SIZE_MIN(), INT_VAL_MIN());

		branch(*this, this->cof_CO, INT_VAR_SIZE_MIN(), INT_VAL_MIN());
		branch(*this, this->cof_SO2, INT_VAR_SIZE_MIN(), INT_VAL_MIN());
		branch(*this, this->cof_O3, INT_VAR_SIZE_MIN(), INT_VAL_MIN());
		branch(*this, this->cof_NO2, INT_VAR_SIZE_MIN(), INT_VAL_MIN());
		branch(*this, this->cof_PM, INT_VAR_SIZE_MIN(), INT_VAL_MIN());
		branch(*this, this->cof_TEMP, INT_VAR_SIZE_MIN(), INT_VAL_MIN());
		branch(*this, this->cof_RH, INT_VAR_SIZE_MIN(), INT_VAL_MIN());
		branch(*this, this->cof_RL, INT_VAR_SIZE_MIN(), INT_VAL_MIN());
	}

	// Search support
	RealtimeScheduling(bool _share, RealtimeScheduling& _rs)
	:Space(_share, _rs)
	{
		this->index_CO.update(*this, _share, _rs.index_CO);
		this->index_SO2.update(*this, _share, _rs.index_SO2);
		this->index_O3.update(*this, _share, _rs.index_O3);
		this->index_NO2.update(*this, _share, _rs.index_NO2);
		this->index_PM.update(*this, _share, _rs.index_PM);
		this->index_TEMP.update(*this, _share, _rs.index_TEMP);
		this->index_RH.update(*this, _share, _rs.index_RH);
		this->index_RL.update(*this, _share, _rs.index_RL);

		this->power_require_per_interval.update(*this, _share, _rs.power_require_per_interval);
		this->power_remian_last_interval.update(*this, _share, _rs.power_remian_last_interval);

		this->index_index_CO.update(*this, _share, _rs.index_index_CO);
		this->index_index_SO2.update(*this, _share, _rs.index_index_SO2);
		this->index_index_O3.update(*this, _share, _rs.index_index_O3);
		this->index_index_NO2.update(*this, _share, _rs.index_index_NO2);
		this->index_index_PM.update(*this, _share, _rs.index_index_PM);
		this->index_index_TEMP.update(*this, _share, _rs.index_index_TEMP);
		this->index_index_RH.update(*this, _share, _rs.index_index_RH);
		this->index_index_RL.update(*this, _share, _rs.index_index_RL);

		this->evenly_CO.update(*this, _share, _rs.evenly_CO);
		this->evenly_SO2.update(*this, _share, _rs.evenly_SO2);
		this->evenly_O3.update(*this, _share, _rs.evenly_O3);
		this->evenly_NO2.update(*this, _share, _rs.evenly_NO2);
		this->evenly_PM.update(*this, _share, _rs.evenly_PM);
		this->evenly_TEMP.update(*this, _share, _rs.evenly_TEMP);
		this->evenly_RH.update(*this, _share, _rs.evenly_RH);
		this->evenly_RL.update(*this, _share, _rs.evenly_RL);

		this->diff_CO_abs.update(*this, _share, _rs.diff_CO_abs);
		this->diff_SO2_abs.update(*this, _share, _rs.diff_SO2_abs);
		this->diff_O3_abs.update(*this, _share, _rs.diff_O3_abs);
		this->diff_NO2_abs.update(*this, _share, _rs.diff_NO2_abs);
		this->diff_PM_abs.update(*this, _share, _rs.diff_PM_abs);
		this->diff_TEMP_abs.update(*this, _share, _rs.diff_TEMP_abs);
		this->diff_RH_abs.update(*this, _share, _rs.diff_RH_abs);
		this->diff_RL_abs.update(*this, _share, _rs.diff_RL_abs);

		this->cof_CO.update(*this, _share, _rs.cof_CO);
		this->cof_SO2.update(*this, _share, _rs.cof_SO2);
		this->cof_O3.update(*this, _share, _rs.cof_O3);
		this->cof_NO2.update(*this, _share, _rs.cof_NO2);
		this->cof_PM.update(*this, _share, _rs.cof_PM);
		this->cof_TEMP.update(*this, _share, _rs.cof_TEMP);
		this->cof_RH.update(*this, _share, _rs.cof_RH);
		this->cof_RL.update(*this, _share, _rs.cof_RL);
	}

	virtual Space* copy(bool _share) 
	{
   		return new RealtimeScheduling(_share, *this);
	}

	virtual void constrain(const Space& current_best) //current_best is the newly found solution
	{
		const RealtimeScheduling &b = static_cast<const RealtimeScheduling&>(current_best);

		//we want to maximize the number of NO_TASK_EXECUTING_INTERVALS
		//because this can save energy while in NO_TASK_EXECUTING_INTERVAL mian MCU is in sleep mode
		// int num_no_task_executing_interval_b = 0;
		// for(int i = 0; i < NUM_TOTAL_INTERVALS; i++)
		// {
		// 	if(b.power_require_per_interval[i].val() == 0)
		// 	{
		// 		num_no_task_executing_interval_b++;
		// 	}
		// }
		// count(*this, power_require_per_interval, 0, IRT_GR, num_no_task_executing_interval_b);

		//if one type of the sensor has sensing rate R, we want these R tasks are distributed evenly in the interval
		rel(*this, 	evenly_CO + evenly_SO2 + evenly_O3 + evenly_NO2 + 
					evenly_PM + evenly_TEMP + evenly_RH + evenly_RL
					< 	b.evenly_CO.val() + b.evenly_SO2.val() + b.evenly_O3.val() + b.evenly_NO2.val() +
						b.evenly_PM.val() + b.evenly_TEMP.val() + b.evenly_RH.val() + b.evenly_RL.val());
	}

	// Print solution
	virtual void print(int i) const
	{
	}

	virtual void print() const
	{
		cout << "index_CO:\t" << this->index_CO << endl;
		cout << "index_SO2:\t" << this->index_SO2 << endl;
		cout << "index_O3:\t" << this->index_O3 << endl;
		cout << "index_NO2:\t" << this->index_NO2 << endl;
		cout << "index_PM:\t" << this->index_PM << endl;
		cout << "index_TEMP:\t" << this->index_TEMP << endl;
		cout << "index_RH:\t" << this->index_RH << endl;
		cout << "index_RL:\t" << this->index_RL << endl;
		cout << "power_require_per_interval:\t" << this->power_require_per_interval << endl;
		cout << "power_remian_last_interval:\t" << this->power_remian_last_interval << endl;

		print_estimate_interval_power();

		// cout << "index_index_CO: " << this->index_index_CO << endl;
		// cout << "index_index_SO2: " << this->index_index_SO2 << endl;
		// cout << "index_index_O3: " << this->index_index_O3 << endl;
		// cout << "index_index_NO2: " << this->index_index_NO2 << endl;
		// cout << "index_index_PM: " << this->index_index_PM << endl;
		// cout << "index_index_TEMP: " << this->index_index_TEMP << endl;
		// cout << "index_index_RH: " << this->index_index_RH << endl;
		// cout << "index_index_RL: " << this->index_index_RL << endl;

		// cout << "cof_CO: " << cof_CO << endl;
		// cout << "cof_SO2: " << cof_SO2 << endl;
		// cout << "cof_O3: " << cof_O3 << endl;
		// cout << "cof_NO2: " << cof_NO2 << endl;
		// cout << "cof_PM: " << cof_PM << endl;
		// cout << "cof_TEMP: " << cof_TEMP << endl;
		// cout << "cof_RH: " << cof_RH << endl;
		// cout << "cof_RL: " << cof_RL << endl;

		// cout << "diff_CO_abs: " << diff_CO_abs << endl;
		// cout << "diff_SO2_abs: " << diff_SO2_abs << endl;
		// cout << "diff_O3_abs: " << diff_O3_abs << endl;
		// cout << "diff_NO2_abs: " << diff_NO2_abs << endl;
		// cout << "diff_PM_abs: " << diff_PM_abs << endl;
		// cout << "diff_TEMP_abs: " << diff_TEMP_abs << endl;
		// cout << "diff_RH_abs: " << diff_RH_abs << endl;
		// cout << "diff_RL_abs: " << diff_RL_abs << endl;

		// cout << "evenly_CO_abs: " << evenly_CO_abs << endl;
		// cout << "evenly_SO2_abs: " << evenly_SO2_abs << endl;
		// cout << "evenly_O3_abs: " << evenly_O3_abs << endl;
		// cout << "evenly_NO2_abs: " << evenly_NO2_abs << endl;
		// cout << "evenly_PM_abs: " << evenly_PM_abs << endl;
		// cout << "evenly_TEMP_abs: " << evenly_TEMP_abs << endl;
		// cout << "evenly_RH_abs: " << evenly_RH_abs << endl;
		// cout << "evenly_RL_abs: " << evenly_RL_abs << endl;

		cout << "evenly_CO:\t" << this->evenly_CO << endl;
		cout << "evenly_SO2:\t" << this->evenly_SO2 << endl;
		cout << "evenly_O3:\t" << this->evenly_O3 << endl;
		cout << "evenly_NO2:\t" << this->evenly_NO2 << endl;
		cout << "evenly_PM:\t" << this->evenly_PM << endl;
		cout << "evenly_TEMP:\t" << this->evenly_TEMP << endl;
		cout << "evenly_RH:\t" << this->evenly_RH << endl;
		cout << "evenly_RL:\t" << this->evenly_RL << endl;

		int total_evenly = 	this->evenly_CO.val() + this->evenly_SO2.val() + this->evenly_O3.val() + this->evenly_NO2.val() + 
							this->evenly_PM.val() + this->evenly_TEMP.val() + this->evenly_RH.val() + this->evenly_RL.val();
		cout << "total_evenly:\t" << total_evenly << endl;

		int num_no_task_executing_interval = 0;
		for(int i = 0; i < NUM_TOTAL_INTERVALS; i++)
		{
			if(this->power_require_per_interval[i].val() == 0)
			{
				num_no_task_executing_interval++;
			}
		}
		cout << "num_no_task_executing_interval:\t" << num_no_task_executing_interval << endl;

		cout << endl;
	}

};

int main(int argc, char* argv[])
{
	init_estimate_interval_power();

	time_t start_time;
	time(&start_time);

	RealtimeScheduling *al = new RealtimeScheduling;
	BAB<RealtimeScheduling> e(al);
	delete al;

	int i = 0;
	while(RealtimeScheduling* al = e.next())
	{
		i++;
		cout << "iteration:\t" << i << endl;
		al->print();
		delete al;
	}

	time_t end_time;
	time(&end_time);

	time_t run_time = end_time - start_time;
	cout << "total time: " << run_time << endl;

	return 0;
}