#include <gecode/int.hh>
#include <gecode/driver.hh>
#include <gecode/int/branch.hh>
#include <gecode/minimodel.hh>
#include <gecode/search.hh>
#include <ctime>

using namespace Gecode;
using namespace std;

#define NUM_TOTAL_INTERVALS 		144		// number of total intervals per day, 24 hours, from 0 to 143, 10 minutes per interval
//#define NUM_PREDICTION_INTERVALS 	3		// number of prediction interval, default is num_perdiction_intervals = 36, 6 hours
int NUM_PREDICTION_INTERVALS = 0;
int NUM_DAYS = 0;
int MODE = 0; //0 uses solar power directly, 1 charges battery first, 2 average the energy to all intervals
#define ENERGY_TRANS_EFFICIENCY 	80		// energy efficiency from harvested energy to battery energy, default is 80%
#define BATTERY_CAPACITY 			4000	// energy capacity of the battery, default is 1000 units of energy
#define ENERGY_EMERGENCY 			200	// the amount of energy must remains in the battery

#define ENERGY_CONSUMPTION_TEMP 5	// energy consumption of temperature sensor for 1 sample
#define ENERGY_CONSUMPTION_RH 	5	// energy consumption of relative humidity sensor for 1 sample
#define ENERGY_CONSUMPTION_CO 	10	// energy consumption of CO sensor for 1 sample
#define ENERGY_CONSUMPTION_SO2 	10	// energy consumption of SO2 sensor for 1 sample
#define ENERGY_CONSUMPTION_O3 	10	// energy consumption of O3 sensor for 1 sample
#define ENERGY_CONSUMPTION_NO2 	10	// energy consumption of NO2 sensor for 1 sample
#define ENERGY_CONSUMPTION_PM 	30	// energy consumption of particulate matter sensor for 1 sample
#define ENERGY_CONSUMPTION_RL 	120	// energy consumption of radio link for 1 transmission

#define REWARD_TEMP 1	// rewards of temperature sensor for 1 sample
#define REWARD_RH 	1	// rewards of relative humidity sensor for 1 sample
#define REWARD_CO 	8	// rewards of CO sensor for 1 sample
#define REWARD_SO2 	8	// rewards of SO2 sensor for 1 sample
#define REWARD_O3 	8	// rewards of O3 sensor for 1 sample
#define REWARD_NO2 	8	// rewards of NO2 sensor for 1 sample
#define REWARD_PM 	15	// rewards of particulate matter sensor for 1 sample

#define DATA_GENERATE_TEMP 	16	// data generated (in bytes) by temperature sensor for 1 sample
#define DATA_GENERATE_RH 	16	// data generated (in bytes) by relative humidity sensor for 1 sample
#define DATA_GENERATE_CO 	16	// data generated (in bytes) by CO sensor for 1 sample
#define DATA_GENERATE_SO2 	16	// data generated (in bytes) by SO2 sensor for 1 sample
#define DATA_GENERATE_O3 	16	// data generated (in bytes) by O3 sensor for 1 sample
#define DATA_GENERATE_NO2 	16	// data generated (in bytes) by NO2 sensor for 1 sample
#define DATA_GENERATE_PM 	16	// data generated (in bytes) by particulate matter sensor for 1 sample
#define DATA_CONSUME_RL 	250	// data consumed (in bytes) by radio link for 1 transmission

#define STEP_DELTA_1 55
#define STEP_DELTA_2 10

int ESTIMATE_ENERGY_PER_INTERVAL[NUM_TOTAL_INTERVALS];
void init_estimate_energy()
{
	for(int i = 0; i < 36; i++) // 0 to 6 o'clock
	{
		ESTIMATE_ENERGY_PER_INTERVAL[i] = 0;
	}
	for(int i = 36; i < 48; i++) //6 o'clock to 8 o'clock
	{
		ESTIMATE_ENERGY_PER_INTERVAL[i] = ESTIMATE_ENERGY_PER_INTERVAL[i - 1] + STEP_DELTA_2;
	}
	for(int i = 48; i < 66; i++) // 8 o'clock to 11 o'clock
	{
		ESTIMATE_ENERGY_PER_INTERVAL[i] = ESTIMATE_ENERGY_PER_INTERVAL[i - 1] + STEP_DELTA_1;
	}
	for(int i = 66; i < 78; i++) // 11 o'clock to 13 o'clock
	{
		ESTIMATE_ENERGY_PER_INTERVAL[i] = ESTIMATE_ENERGY_PER_INTERVAL[i - 1] + STEP_DELTA_2;
	}
	for(int i = 78; i < 90; i++) // 13 o'clock to 15 o'clock
	{
		ESTIMATE_ENERGY_PER_INTERVAL[i] = ESTIMATE_ENERGY_PER_INTERVAL[i - 1] - STEP_DELTA_2;
	}
	for(int i = 90; i < 108; i++) // 15 o'clock to 18 o'clock
	{
		ESTIMATE_ENERGY_PER_INTERVAL[i] = ESTIMATE_ENERGY_PER_INTERVAL[i - 1] - STEP_DELTA_1;
	}
	for(int i = 108; i < NUM_TOTAL_INTERVALS; i++) // 18 o'clock to 23:50 o'clock
	{
		ESTIMATE_ENERGY_PER_INTERVAL[i] = 0;
	}
}

void print_estimate_energy()
{
	for(int i = 0; i < NUM_TOTAL_INTERVALS; i++)
	{
		cout << ESTIMATE_ENERGY_PER_INTERVAL[i];
		if((i + 1) % 6 == 0)
		{
			cout << endl;
		}
		else
		{
			cout << " ";
		}
	}
	cout << endl;
}

void shift_estimate_erergy(int _current_interval) // ESTIMATE_ENERGY_PER_INTERVAL[0] is at 12:00 pm
{
	int temp[NUM_TOTAL_INTERVALS];
	int index = 0;

	int offset = 0; // 66

	if(_current_interval >= NUM_TOTAL_INTERVALS)
	{
		_current_interval %= NUM_TOTAL_INTERVALS;
	}

	for(int i = 0; i < NUM_TOTAL_INTERVALS; i++)
	{
		if(i + offset + _current_interval < NUM_TOTAL_INTERVALS)
		{
			index = offset + i + _current_interval;
		}
		else
		{
			index = (offset + i + _current_interval) % NUM_TOTAL_INTERVALS;
		}

		temp[i] = ESTIMATE_ENERGY_PER_INTERVAL[index];
	}
	for(int i = 0; i < NUM_TOTAL_INTERVALS; i++)
	{
		ESTIMATE_ENERGY_PER_INTERVAL[i] = temp[i];
	}
}

int LAST_REMAIN_ENERGY;
int REMAIN_ENERGY;
int WASTED_ENERGY;
void set_remain_energy(int _initial_remain_energy)
{
	LAST_REMAIN_ENERGY = _initial_remain_energy;
}

int AVERAGE_ENERGY;
void calculate_average_energy()
{
	for(int i = 0; i < NUM_TOTAL_INTERVALS; i++)
	{
		AVERAGE_ENERGY += ESTIMATE_ENERGY_PER_INTERVAL[i] * ENERGY_TRANS_EFFICIENCY / 100.0;
	}

	AVERAGE_ENERGY /= NUM_TOTAL_INTERVALS;
}

int INTERVAL_ENERGY;
int ESTIMATE_ENERGY;
int RATE_CO;
int RATE_SO2;
int RATE_O3;
int RATE_NO2;
int RATE_PM;
int RATE_TEMP;
int RATE_RH;
int RATE_RL;

class ApplicationLevel: public Space
{
protected:
	IntVar rate_CO;
	IntVar rate_SO2;
	IntVar rate_O3;
	IntVar rate_NO2;
	IntVar rate_PM;
	IntVar rate_TEMP;
	IntVar rate_RH;
	IntVar rate_RL;

	IntVar remain_energy;

public:
	ApplicationLevel(void)
	:rate_CO(*this, 0, 10), rate_SO2(*this, 0, 10),
	rate_O3(*this, 0, 10), rate_NO2(*this, 0, 10),
	rate_PM(*this, 0, 10), rate_TEMP(*this, 0, 10), 
	rate_RH(*this, 0, 10), rate_RL(*this, 0, 10), remain_energy(*this, 0, BATTERY_CAPACITY)
	{
		int energy;
		if(MODE == 0) //use solar power directly
		{
			energy = ESTIMATE_ENERGY_PER_INTERVAL[0];
		}
		if(MODE == 1) //charge battery first
		{
			energy = ESTIMATE_ENERGY_PER_INTERVAL[0] * ENERGY_TRANS_EFFICIENCY / 100.0;
			energy += LAST_REMAIN_ENERGY;
		}
		if(MODE == 2) //average the energy in the while day
		{
			if(ESTIMATE_ENERGY_PER_INTERVAL[0] * ENERGY_TRANS_EFFICIENCY / 100.0 + LAST_REMAIN_ENERGY >= AVERAGE_ENERGY)
			{
				energy = AVERAGE_ENERGY;
			}
			else
			{
				energy = 0;
			}
		}

		//total energy of each interval must satisfy the energy constraint
		IntVar interval_energy = expr(*this, this->rate_CO * ENERGY_CONSUMPTION_CO + this->rate_SO2 * ENERGY_CONSUMPTION_SO2 + 
			this->rate_O3 * ENERGY_CONSUMPTION_O3 + this->rate_NO2 * ENERGY_CONSUMPTION_NO2 + 
			this->rate_PM * ENERGY_CONSUMPTION_PM + this->rate_TEMP * ENERGY_CONSUMPTION_TEMP + 
			this->rate_RH * ENERGY_CONSUMPTION_RH + this->rate_RL * ENERGY_CONSUMPTION_RL);

		rel(*this, interval_energy <= energy);

		if(MODE == 0)
		{
			rel(*this, remain_energy == 0);
		}
		if(MODE == 1)
		{
			rel(*this, remain_energy == expr(*this, energy - interval_energy));
			rel(*this, remain_energy <= BATTERY_CAPACITY);
			rel(*this, remain_energy >= ENERGY_EMERGENCY);
		}
		if(MODE == 2)
		{
			BoolVar max_remain = expr(*this, (ESTIMATE_ENERGY_PER_INTERVAL[0] * ENERGY_TRANS_EFFICIENCY / 100.0 + LAST_REMAIN_ENERGY - interval_energy) <= BATTERY_CAPACITY);
			if(max_remain.one())
			{
				rel(*this, remain_energy == expr(*this, ESTIMATE_ENERGY_PER_INTERVAL[0] * ENERGY_TRANS_EFFICIENCY / 100.0 + LAST_REMAIN_ENERGY - interval_energy));
				rel(*this, remain_energy <= BATTERY_CAPACITY);
				rel(*this, remain_energy >= ENERGY_EMERGENCY);
			}
			else
			{
				rel(*this, remain_energy == BATTERY_CAPACITY);
			}
		}

		//each sensor must sample at least once in one interval
		rel(*this, this->rate_CO >= 1);
		rel(*this, this->rate_SO2 >= 1);
		rel(*this, this->rate_O3 >= 1);
		rel(*this, this->rate_NO2 >= 1);
		rel(*this, this->rate_PM >= 1);
		rel(*this, this->rate_TEMP >= 1);
		rel(*this, this->rate_RH >= 1);

		//the sensing rates of CO, SO2, O3 and NO2 sensors are distributed evenly
		rel(*this, this->rate_CO == this->rate_SO2);
		rel(*this, this->rate_SO2 == this->rate_O3);
		rel(*this, this->rate_O3 == this->rate_NO2);
		rel(*this, this->rate_NO2 == this->rate_CO);

		//the sensing rate of PM sensor should not less than 1/2 of CO, SO2, O3 and NO2 sensor
		rel(*this, this->rate_PM >= this->rate_CO / 2);
		rel(*this, this->rate_PM <= this->rate_CO);

		//the sensing rates of TEMP and RH sensors are distributed evenly
		rel(*this, this->rate_TEMP == this->rate_RH);

		//the CO, SO2, O3, NO2 and PM sensors are more important than the TEMP and RH sensors
		rel(*this, this->rate_CO > this->rate_TEMP);
		rel(*this, this->rate_PM > this->rate_TEMP);

		//data should be transmitted back to server every interval
		IntVar interval_generate_data = expr(*this, this->rate_CO * DATA_GENERATE_CO + this->rate_SO2 * DATA_GENERATE_SO2 + 
			this->rate_O3 * DATA_GENERATE_O3 + this->rate_NO2 * DATA_GENERATE_NO2 + 
			this->rate_PM * DATA_GENERATE_PM + this->rate_TEMP * DATA_GENERATE_TEMP + 
			this->rate_RH * DATA_GENERATE_RH);
		IntVar interval_consume_data = expr(*this, this->rate_RL * DATA_CONSUME_RL);
		rel(*this, interval_generate_data <= interval_consume_data);

		branch(*this, this->rate_CO, INT_VAL_MIN());
		branch(*this, this->rate_SO2, INT_VAL_MIN());
		branch(*this, this->rate_O3, INT_VAL_MIN());
		branch(*this, this->rate_NO2, INT_VAL_MIN());
		branch(*this, this->rate_PM, INT_VAL_MIN());
		branch(*this, this->rate_TEMP, INT_VAL_MIN());
		branch(*this, this->rate_RH, INT_VAL_MIN());
		branch(*this, this->rate_RL, INT_VAL_MIN());
		
		if(MODE == 1 || MODE == 2)
		{
			branch(*this, this->remain_energy, INT_VAL_MAX());
		}
	}

	// Search support
	ApplicationLevel(bool _share, ApplicationLevel& _al)
	:Space(_share, _al)
	{
		this->rate_CO.update(*this, _share, _al.rate_CO);
		this->rate_SO2.update(*this, _share, _al.rate_SO2);
		this->rate_O3.update(*this, _share, _al.rate_O3);
		this->rate_NO2.update(*this, _share, _al.rate_NO2);
		this->rate_PM.update(*this, _share, _al.rate_PM);
		this->rate_TEMP.update(*this, _share, _al.rate_TEMP);
		this->rate_RH.update(*this, _share, _al.rate_RH);
		this->rate_RL.update(*this, _share, _al.rate_RL);
		this->remain_energy.update(*this, _share, _al.remain_energy);
	}

	virtual Space* copy(bool _share) 
	{
   		return new ApplicationLevel(_share, *this);
	}

	virtual void constrain(const Space& current_best) //current_best is the newly found solution
	{
		const ApplicationLevel &b = static_cast<const ApplicationLevel&>(current_best);

		// int total_reward[NUM_PREDICTION_INTERVALS];
		// for(int i = 0; i < NUM_PREDICTION_INTERVALS; i++)
		// {
		// 	total_reward[i] = 0;
		// 	total_reward[i] += REWARD_CO * b.rate_CO[i].val();
		// 	total_reward[i] += REWARD_SO2 * b.rate_SO2[i].val();
		// 	total_reward[i] += REWARD_O3 * b.rate_O3[i].val();
		// 	total_reward[i] += REWARD_NO2 * b.rate_NO2[i].val();
		// 	total_reward[i] += REWARD_PM * b.rate_PM[i].val();
		// 	total_reward[i] += REWARD_TEMP * b.rate_TEMP[i].val();
		// 	total_reward[i] += REWARD_RH * b.rate_RH[i].val();

		// 	rel(*this, 	REWARD_CO * this->rate_CO[i] + REWARD_SO2 * this->rate_SO2[i] + REWARD_O3 * this->rate_O3[i] +
		// 				REWARD_NO2 * this->rate_NO2[i] + REWARD_PM * this->rate_PM[i] + REWARD_TEMP * this->rate_TEMP[i] +
		// 				REWARD_RH * this->rate_RH[i] > total_reward[i]);
		// }

		int total_reward_b = 0;
		total_reward_b += REWARD_CO * b.rate_CO.val();
		total_reward_b += REWARD_SO2 * b.rate_SO2.val();
		total_reward_b += REWARD_O3 * b.rate_O3.val();
		total_reward_b += REWARD_NO2 * b.rate_NO2.val();
		total_reward_b += REWARD_PM * b.rate_PM.val();
		total_reward_b += REWARD_TEMP * b.rate_TEMP.val();
		total_reward_b += REWARD_RH * b.rate_RH.val();

		IntVar total_reward;
		total_reward = expr(*this, 
			REWARD_CO * this->rate_CO + REWARD_SO2 * this->rate_SO2 + REWARD_O3 * this->rate_O3 +
			REWARD_NO2 * this->rate_NO2 + REWARD_PM * this->rate_PM + REWARD_TEMP * this->rate_TEMP +
			REWARD_RH * this->rate_RH);

		rel(*this, total_reward > total_reward_b);
	}

	// Print solution
	virtual void print(int i) const
	{
		RATE_CO = this->rate_CO.val();
		RATE_SO2 = this->rate_SO2.val();
		RATE_O3 = this->rate_O3.val();
		RATE_NO2 = this->rate_NO2.val();
		RATE_PM = this->rate_PM.val();
		RATE_TEMP = this->rate_TEMP.val();
		RATE_RH = this->rate_RH.val();
		RATE_RL = this->rate_RL.val();

		INTERVAL_ENERGY = 0;
		INTERVAL_ENERGY += ENERGY_CONSUMPTION_CO * this->rate_CO.val();
		INTERVAL_ENERGY += ENERGY_CONSUMPTION_SO2 * this->rate_SO2.val();
		INTERVAL_ENERGY += ENERGY_CONSUMPTION_O3 * this->rate_O3.val();
		INTERVAL_ENERGY += ENERGY_CONSUMPTION_NO2 * this->rate_NO2.val();
		INTERVAL_ENERGY += ENERGY_CONSUMPTION_PM * this->rate_PM.val();
		INTERVAL_ENERGY += ENERGY_CONSUMPTION_TEMP * this->rate_TEMP.val();
		INTERVAL_ENERGY += ENERGY_CONSUMPTION_RH * this->rate_RH.val();
		INTERVAL_ENERGY += ENERGY_CONSUMPTION_RL * this->rate_RL.val();

		ESTIMATE_ENERGY = ESTIMATE_ENERGY_PER_INTERVAL[0];

		if(MODE == 0 || MODE == 1)
		{
			REMAIN_ENERGY = this->remain_energy.val();
		}
		if(MODE == 2)
		{
			REMAIN_ENERGY = ESTIMATE_ENERGY * ENERGY_TRANS_EFFICIENCY / 100.0 + LAST_REMAIN_ENERGY - INTERVAL_ENERGY;
			if(REMAIN_ENERGY > BATTERY_CAPACITY)
			{
				REMAIN_ENERGY = BATTERY_CAPACITY;
			}
		}

		if(MODE == 0)
		{
			WASTED_ENERGY = ESTIMATE_ENERGY - INTERVAL_ENERGY;
		}
		if(MODE == 1)
		{
			WASTED_ENERGY = ESTIMATE_ENERGY * (100 - ENERGY_TRANS_EFFICIENCY) / 100.0;
		}
		if(MODE == 2)
		{
			WASTED_ENERGY = ESTIMATE_ENERGY * (100 - ENERGY_TRANS_EFFICIENCY) / 100.0;	

			if(ESTIMATE_ENERGY * ENERGY_TRANS_EFFICIENCY / 100.0 + LAST_REMAIN_ENERGY - INTERVAL_ENERGY > BATTERY_CAPACITY)
			{
				WASTED_ENERGY += ESTIMATE_ENERGY * ENERGY_TRANS_EFFICIENCY / 100.0 + LAST_REMAIN_ENERGY - INTERVAL_ENERGY - BATTERY_CAPACITY;
			}
		}
	}

	virtual void print() const
	{
		cout << "rate_CO: " << this->rate_CO << endl;
		cout << "rate_SO2: " << this->rate_SO2 << endl;
		cout << "rate_O3: " << this->rate_O3 << endl;
		cout << "rate_NO2: " << this->rate_NO2 << endl;
		cout << "rate_PM: " << this->rate_PM << endl;
		cout << "rate_TEMP: " << this->rate_TEMP << endl;
		cout << "rate_RH: " << this->rate_RH << endl;
		cout << "rate_RL: " << this->rate_RL << endl;

		int total_reward = 0;
		total_reward += REWARD_CO * this->rate_CO.val();
		total_reward += REWARD_SO2 * this->rate_SO2.val();
		total_reward += REWARD_O3 * this->rate_O3.val();
		total_reward += REWARD_NO2 * this->rate_NO2.val();
		total_reward += REWARD_PM * this->rate_PM.val();
		total_reward += REWARD_TEMP * this->rate_TEMP.val();
		total_reward += REWARD_RH * this->rate_RH.val();
		cout << "total_reward: " << total_reward << endl;
		
		cout << "remain_energy: " << remain_energy << endl;

		cout << "estimate_energy_per_interval:\t";
		cout << ESTIMATE_ENERGY_PER_INTERVAL[0] << "\t";
		cout << endl;
		
		cout << "interval_energy:\t\t";
		int interval_energy = 0;
		interval_energy += ENERGY_CONSUMPTION_CO * this->rate_CO.val();
		interval_energy += ENERGY_CONSUMPTION_SO2 * this->rate_SO2.val();
		interval_energy += ENERGY_CONSUMPTION_O3 * this->rate_O3.val();
		interval_energy += ENERGY_CONSUMPTION_NO2 * this->rate_NO2.val();
		interval_energy += ENERGY_CONSUMPTION_PM * this->rate_PM.val();
		interval_energy += ENERGY_CONSUMPTION_TEMP * this->rate_TEMP.val();
		interval_energy += ENERGY_CONSUMPTION_RH * this->rate_RH.val();
		interval_energy += ENERGY_CONSUMPTION_RL * this->rate_RL.val();
		cout << interval_energy << "\t";
		cout << endl << endl;
	}

};

void execute(int _current_interval, int _last_remain_energy)
{
	RATE_CO = RATE_SO2 = RATE_O3 = RATE_NO2 = RATE_PM = RATE_TEMP = RATE_RH = RATE_RL =  INTERVAL_ENERGY = 0;
	ESTIMATE_ENERGY = ESTIMATE_ENERGY_PER_INTERVAL[0];
	WASTED_ENERGY = 0;

	init_estimate_energy();
	shift_estimate_erergy(_current_interval);

	set_remain_energy(_last_remain_energy);

	calculate_average_energy();

	ApplicationLevel *al = new ApplicationLevel;
	BAB<ApplicationLevel> e(al);
	delete al;

	int i = 0;
	while(ApplicationLevel* al = e.next())
	{
		i++;
		al->print(0);
		delete al;
	}

	if(i == 0)
	{
		if(MODE == 0)
		{
			REMAIN_ENERGY = LAST_REMAIN_ENERGY = 0;
			WASTED_ENERGY = ESTIMATE_ENERGY;
		}
		if(MODE == 1)
		{
			REMAIN_ENERGY = LAST_REMAIN_ENERGY + ESTIMATE_ENERGY * ENERGY_TRANS_EFFICIENCY / 100.0;
			WASTED_ENERGY = ESTIMATE_ENERGY * (100 - ENERGY_TRANS_EFFICIENCY) / 100.0;
		}
		if(MODE == 2)
		{
			REMAIN_ENERGY = LAST_REMAIN_ENERGY + ESTIMATE_ENERGY * ENERGY_TRANS_EFFICIENCY / 100.0;
			WASTED_ENERGY = ESTIMATE_ENERGY * (100 - ENERGY_TRANS_EFFICIENCY) / 100.0;
		}
	}

	cout << RATE_CO << " ";
	cout << RATE_SO2 << " ";
	cout << RATE_O3 << " ";
	cout << RATE_NO2 << " ";
	cout << RATE_PM << " ";
	cout << RATE_TEMP << " ";
	cout << RATE_RH << " ";
	cout << RATE_RL << " ";
	cout << LAST_REMAIN_ENERGY << " ";
	cout << ESTIMATE_ENERGY << " "; 
	cout << INTERVAL_ENERGY << " ";
	cout << WASTED_ENERGY << " ";
	cout << REMAIN_ENERGY << endl;

	// cout << "rate_CO: " << RATE_CO << " ";
	// cout << "rate_SO2: " << RATE_SO2 << " ";
	// cout << "rate_O3: " << RATE_O3 << " ";
	// cout << "rate_NO2: " << RATE_NO2 << " ";
	// cout << "rate_PM: " << RATE_PM << " ";
	// cout << "rate_TEMP: " << RATE_TEMP << " ";
	// cout << "rate_RH: " << RATE_RH << " ";
	// cout << "rate_RL: " << RATE_RL << " ";
	// cout << "last_remain_energy: " << LAST_REMAIN_ENERGY << " ";
	// cout << "estimate_energy: " << ESTIMATE_ENERGY << " "; 
	// cout << "interval_energy: " << INTERVAL_ENERGY << " ";
	// cout << "remain_energy: " << REMAIN_ENERGY << endl;
}

int main(int argc, char* argv[])
{
	MODE = atoi(argv[1]);
	NUM_DAYS = atoi(argv[2]);

	time_t start_time;
	time(&start_time);

	for(int i = 0; i < NUM_DAYS * NUM_TOTAL_INTERVALS; i++) //3 days
	{	
		cout << i << " ";

		if(i == 0)
		{
			execute(i, ENERGY_EMERGENCY);
		}
		else
		{
			execute(i, REMAIN_ENERGY);
		}
	}

	time_t end_time;
	time(&end_time);

	time_t run_time = end_time - start_time;
	cout << "total time: " << run_time << endl;
	return 0;
}